import Meal
from SPXCafe2 import SPXCafe
from rapidfuzz.fuzz import partial_ratio
class Course(SPXCafe):
    '''Course class - holds information about menu course'''

    def __init__(self, courseId = None, courseName=None, meals = None):
        '''constructore method for a course'''

        super().__init__()
        self.setCourseId(courseId)
        self.setCourseName(courseName)
        self.setMeals(meals)

        # set the meals aggregation for this course - eg list of meals for course
        
        if self.existsDB():
            if not self.setCourse():
                print(f"Course: Course Id <{self.getCourseId()}> is invalid")

    def setCourse(self, courseId=None):
        '''retrieve course data from datbase'''
        retcode = False
        if courseId:
            self.setCourseId(courseId)

        if self.getCourseId():
            sql = f"SELECT courseId, courseName FROM courses WHERE courseId={self.getCourseId()}"
            courseData = self.dbGetData(sql)

            if courseData: # course found in database
                for course in courseData: #retrieve data
                    self.setCourseId(course['courseId'])
                    self.setCourseName(course['courseName'])
                    self.setMeals(Meal.Meal.getMeals(self)) #aggregation!
                    retcode = True
        
        return retcode
    
    #getters/ setters
    def setCourseId(self, courseId):
        self.__courseId = courseId
    
    def setCourseName(self, courseName):
        if courseName:
            self.__courseName = courseName.lower()
        else:
            self.__courseName = None

    def setMeals(self, meals=None):
        if meals:
            self.__meals = meals
        else: 
            self.__meals = []
    def addMeal(self, meal=None):
        # print(type(meal))
        if meal:
            self.__meals.append(meal)
            meal.setCourse(self)

    def getCourseId(self):
        return self.__courseId
    def getCourseName(self):
        return self.__courseName
    def getMeals(self):
        return self.__meals
    def findMeal(self, searchMeal):
        meals = []
        if searchMeal:
            for meal in self.getMeals:
                meals.append(meal.findMeal(searchMeal))
        return meals  

    def __str__(self):
        '''return a stringfied version of object for printing'''
        return f"Course <{self.getCourseId()}> {self.getCourseName().title() if self.getCourseName() else "<unkown>"}"
        # return f"{self.getCourseName().title() if self.getCourseName() else "<unkown>"}"
    
    def display(self):
        '''print the course detauls'''
        print(self)
        for meal in self.getMeals():
            meal.display()
    # Persistant data - database- related methods

    def existsDB(self):
        '''check if object already exists in datbase'''
        retcode = False
        if self.getCourseId():
            sql = f"SELECT count(*) AS count FROM courses WHERE courseId={self.getCourseId()}"
            countData = self.dbGetData(sql)
            if countData:
                for countData in self.dbGetData(sql):
                    count = int(countData['count'])
                if count > 0:
                    retcode = True
        return retcode
    def save(self):
        '''Save course data back to the database'''

        if self.existsDB():
            sql = f'''UPDATE courses SET
                courseId ={self.getCourseId()},
                courseName='{self.getCourseName()}
                WHERE courseId={self.getCourseId()}
            '''
            self.dbChangeData(sql)
        else:
            sql = f'''
                INSERT INTO courses
                (courseName)
                VALUES
                ('{self.getCourseName()}')
                '''
            #save new primary key
            self.setCourseId(self.dbPutData(sql))

    def delete(self):
        '''Deletes an instance of a course from the database only if there are no children meals'''
        if len(self.getMeals())==0:
            sql = f"DELETE FROM courses WHERE courseId={self.getCourseId()}"
            self.dbChangeData(sql)
        else:
            print(f"Cannot delete Course {self.getCourseId()}-{self.getCourseName().title()} -  Meals attached")

    @classmethod
    def getCourses(cls,menu=None):
        '''Class method: gets all courses obejcts/ instances for Menu - example of aggregation'''
        sql = "SELECT courseId, courseName FROM courses ORDER BY courseId"
        #print(f"get all courses: {sql}")
        coursesData = SPXCafe().dbGetData(sql)
        courses = []
        for courseData in coursesData:
            # create a new instance
            course = cls.__new__(cls)
            course.setCourseId(courseData['courseId'])
            course.setCourseName(courseData['courseName'])
            course.setMeals(Meal.Meal.getMeals(course))
            # add course object to courses list
            courses.append(course)
        return courses
    
    def findMeal(self, searchMeal=None):
        meals = []
        if searchMeal:
            for meal in self.getMeals():
                if meal.isMatch(searchMeal):
                    meals.append(meal)
        return meals
        #     if self.isMatch(searchMeal):
        #         print("success find meal in course")
        #         return self
        # print("failed find meal in course")    
    def findCourse(self, searchCourse=None):
        if searchCourse:
            if self.isMatch(searchCourse):
                # print(self.isMatch(searchCourse))
                return self
        return None
    
    def isMatch(self, courseName= None):
        # self.getCourses()
        confidence = partial_ratio(courseName.lower(), self.getCourseName())
        # print(courseName, self.getCourseName(), confidence)
        if confidence >=80:
            return True
        else:
            return False
    # def getCoursesDb(self):
    #     courses = []
    #     sql = None
    #     sql = f'''SELECT courseId, courseName FROM courses ORDER BY courseId'''
    #     courseData = self.dbGetData(sql)
    #     for coursesData in courseData:
    #         # courses.display()
    #         print(courses)
    #         self.setCourseId(coursesData['courseId'])
    #         self.setCourseName(coursesData['courseName'])
    #         print(self.getCourseId())
    #         self.setMeals(Meal.Meal.getMeals(self.getCourseId()))
    #         # add course object to courses list
    #         courses.append([self.getCourseName(),self.getMeals()])
    #     return courses
    # def matches(self):
    #     courses = self.getCoursesDb()
    #     for course in courses:
    # dMealName(self, mealId):
    #     mealID = mealId
    #     mealIdentification = Meal.Meal().findMealName(mealID)
    #     return mealIdentification
#         self.display(course)
    # def fin
def main():
    '''Test harness to make sure all methods work'''

    # course = Course(1)
    # course.display()
    # course.setCourseName(course.getCourseName()+"X")
    # course.save()
    course = Course()
    course.display()
    # course.findCourse("entree")
    # x = course.findCourse(searchCourse="starter")
    # course.matches()
    # print(x)
    # course.getCoursesDb()
    # course1 = Course(courseName="New course")
    # course1.save()
    # course1.display()
    
    
    # print("newMeal")
    # meal = Meal.Meal(mealName="New Meal", mealPrice=99.99, course=course1)
    # # meal.save()
    # # meal.display()
    # searchMeal = input("Search Meal: ").lower().strip()
    # meals = Course.findMeal(searchMeal)
    # print(f"search Results for ' {searchMeal}' in {course.getCourseName()}")
    # for meal in meals:
    #     print(f">>>> {meal}")

    # searchMeal = input("Search Cours? ").lower().strip()
    # course= course.findMeal(searchMeal)
    # print(course)
    # if course: 
    #     print(f"search Results for '{searchMeal}' is ")
    # else:
    #     print(f";{searchMeal}' was not found!")

    # print("add meal to course")
if __name__=="__main__":
    main()