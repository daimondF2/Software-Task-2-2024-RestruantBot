from datetime import datetime

import spacy

class NLPdemo():

    def __init__(self):
        print(f"Please Wait.... ")
        self.nlp = spacy.load("en_core_web_sm")
        print(f".... Finished Loarding <{datetime.now()}")

    def getNameByPartsOfSpeech(self, speech):
        names= []
        doc = self.nlp(speech)
        # parts of speeech (Pis) Tagging
        for token in doc:

            # print(f"{token.text:10s}, {token.lemma_:10s}, {token.pos_:10s}, {token.tag_:5s}, {token.dep_:10s}, {token.shape_:10s}, {token.is_alpha}, {token.is_stop}")

            if token.pos_ in ["PROPN"]:
                names.append(token.text)
        
        name = " ".join(names)
        return name
    def getNameByEntityType(self, speech):
        names = []
        doc =self.nlp(speech)
        print("Entities found: ")
        for ent in doc.ents:
            # print(ent.text, ent.start_char, ent.end_char, ent.label_)

            if ent.label_ == 'PERSON':
                names.append(ent.text)
        name = " ".join(names)
        # print(name)
        return name
    def getMealByType(self, speech):
        meals = []
        doc = self.nlp(speech)
        for token in doc:
            # print(f"{token.text:10s}, {token.lemma_:10s}, {token.pos_:10s}, {token.tag_:5s}, {token.dep_:10s}, {token.shape_:10s}, {token.is_alpha}, {token.is_stop}")
            if token.pos_ in ["NOUN"]:
                meals.append(token.text)
        meal = " ".join(meals)
        # print(meal)
        # for ent in doc.ents:
        #     print(ent.text, ent.start, ent.start_char, ent.end_char, ent.label_)
        return meal
    def getQuantityBySpeech(self, speech):
        quantity = []
        doc = self.nlp(speech)
        for token in doc:
            print(f"{token.text:10s}, {token.lemma_:10s}, {token.pos_:10s}, {token.tag_:5s}, {token.dep_:10s}, {token.shape_:10s}, {token.is_alpha}, {token.is_stop}")
            if token.pos_ in ["NUM"]:
                quantity.append(token.text)
        return quantity[0]
                
    
def main():
    nlpdem = NLPdemo()
    sentence = "I would like 3 no 5"
    print(f">>>>> Process: {sentence}")
    name= int(nlpdem.getQuantityBySpeech(sentence))
    h = name*2
    print(h)
    print(f">>> name by speech found: {name}")

if __name__=="__main__":
    main()

# pip install -U pip setuptools wheel
# pip install -U spacy
# python -m spacy download en_core_web_sm